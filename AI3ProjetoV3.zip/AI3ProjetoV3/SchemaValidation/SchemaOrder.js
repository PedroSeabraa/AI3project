var mongoose = require('mongoose');
var Schema = mongoose.Schema;

const OrderSchema = new Schema({
  userId: Number,
  address: String,
  productsId: Number,
  shipDate: Date,
  Description: String,
  status: String
  });
 


module.exports = mongoose.model('Order', OrderSchema);
