'use strict';

//meter esta ligacao noutra pagina e chamala com required
const mongoose = require('mongoose');
const { update } = require('../SchemaValidation/SchemaOrder.js');
var Order = require('../SchemaValidation/SchemaOrder.js');
mongoose.connect('mongodb+srv://ai3:ai3@clusterai3.f3gj7.mongodb.net/ai3?retryWrites=true&w=majority', {useNewUrlParser: true});

/**
 * Send a new order
 * 
 *
 * body Order Order object that needs to be added to the app
 * no response value expected for this operation
 **/
exports.addOrder = function(body) {
  return new Promise(function(resolve, reject) {
    console.log("Tryng to add Order");
    
    Order = mongoose.model('Order', 'Orders');
    var NewOrder = new Order({
      "userId": body.userId,
      "address": body.address,
      "productsId": body.productsId,
      "shipDate": body.shipDate,
      "Description": body.Description,
      "status": body.status
    });
    NewOrder
     .save()
     .then(saved => {
      resolve(200);
     })//acrescentar erros de diferentes situacoes
     .catch(error => {
       reject(400);
     });
})
}


/**
 * Deletes a order
 * 
 *
 * orderId Long Order id to delete
 * api_key String  (optional)
 * returns List
 **/
exports.deleteOrder = function(orderId,api_key) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "address" : "address",
  "quantity" : 1,
  "id" : 0,
  "shipDate" : "2000-01-23T04:56:07.000+00:00",
  "complete" : false,
  "Description" : "productDescription",
  "status" : "placed"
}, {
  "address" : "address",
  "quantity" : 1,
  "id" : 0,
  "shipDate" : "2000-01-23T04:56:07.000+00:00",
  "complete" : false,
  "Description" : "productDescription",
  "status" : "placed"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Finds Orders by status
 * Multiple status values can be provided with comma separated strings
 *
 * status List Status values that need to be considered for filter
 * returns List
 **/
exports.findOrdersByStatus = function(status) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "address" : "address",
  "quantity" : 1,
  "id" : 0,
  "shipDate" : "2000-01-23T04:56:07.000+00:00",
  "complete" : false,
  "Description" : "productDescription",
  "status" : "placed"
}, {
  "address" : "address",
  "quantity" : 1,
  "id" : 0,
  "shipDate" : "2000-01-23T04:56:07.000+00:00",
  "complete" : false,
  "Description" : "productDescription",
  "status" : "placed"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Finds orders by tags
 * Muliple tags can be provided with comma separated strings. Use         tag1, tag2, tag3 for testing.
 *
 * tags List Tags to filter by
 * returns List
 **/
exports.findOrdersByTags = function(tags) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "address" : "address",
  "quantity" : 1,
  "id" : 0,
  "shipDate" : "2000-01-23T04:56:07.000+00:00",
  "complete" : false,
  "Description" : "productDescription",
  "status" : "placed"
}, {
  "address" : "address",
  "quantity" : 1,
  "id" : 0,
  "shipDate" : "2000-01-23T04:56:07.000+00:00",
  "complete" : false,
  "Description" : "productDescription",
  "status" : "placed"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Find order by ID
 * Returns a single order
 *
 * orderId Long ID of order to return
 * returns Order
 **/
exports.getOrderById = function(orderId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "address" : "address",
  "quantity" : 1,
  "id" : 0,
  "shipDate" : "2000-01-23T04:56:07.000+00:00",
  "complete" : false,
  "Description" : "productDescription",
  "status" : "placed"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update an existing order
 * 
 *
 * body Order Order object that needs to be added to the app
 * returns Order
 **/
exports.updateOrder = function(body) {
  
  return new Promise(function(resolve, reject) {
    console.log("Trying to update");
    Order = mongoose.model('Order', 'Orders');
   
    const filter = { Description:body.Description };
    const update = { status:body.status};
    
    // `doc` is the document _after_ `update` was applied because of
    // `new: true`
    let doc = await Order.findOneAndUpdate(filter, update, {
      new: true
    
    });
  
 


  })
}


/**
 * Updates a order in the store with form data
 * 
 *
 * orderId Long ID of order that needs to be updated
 * name String Update name of the order (optional)
 * status String Updated status of the order (optional)
 * no response value expected for this operation
 **/
exports.updateOrderWithForm = function(orderId,name,status) {
  return new Promise(function(resolve, reject) {
    
    resolve();
  });
}

