'use strict';

var utils = require('../utils/writer.js');
var User = require('../service/UserService');





module.exports.createUser = function createUser (req, res, next) {
  var body = req.swagger.params['body'].value;
  User.createUser(body)
    .then(function (response) {
      utils.writeJson(res, "Inserido com sucesso",response);
    })
    .catch(function (response) {
      console.log(response);
    utils.writeJson(res, "Nao foi possível inserir o registo",response);
    });
    





    var mongoose = require('mongoose');
 
    // make a connection
    mongoose.connect('mongodb+srv://ai3:ai3@clusterai3.f3gj7.mongodb.net/ai3?retryWrites=true&w=majority');
     
    // get reference to database
    var db = mongoose.connection;
     
    db.on('error', console.error.bind(console, 'connection error:'));
     
    db.once('open', function() {
        console.log("Connection Successful!");
        


        
        // define Schema
        var UserSchema = mongoose.Schema({
          name: String,
          price: Number,
          quantity: Number
        });
     
        // compile schema to model
        var User = mongoose.model('User', UserSchema, 'app');
     
        // a document instance
        var User1 = new User({ name: 'Introduction to Mongoose', price: 10, quantity: 25 });
     
        // save model to database
        book1.save(function (err, book) {
          if (err) return console.error(err);
          console.log(book.name + " saved to bookstore collection.");
        });
        
    });








};

module.exports.createUsersWithArrayInput = function createUsersWithArrayInput (req, res, next) {
  var body = req.swagger.params['body'].value;
  User.createUsersWithArrayInput(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.createUsersWithListInput = function createUsersWithListInput (req, res, next) {
  var body = req.swagger.params['body'].value;
  User.createUsersWithListInput(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteUser = function deleteUser (req, res, next) {
  var username = req.swagger.params['username'].value;
  User.deleteUser(username)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getUserByName = function getUserByName (req, res, next) {
  var username = req.swagger.params['username'].value;
  User.getUserByName(username)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.loginUser = function loginUser (req, res, next) {
  var email = req.swagger.params['email'].value;
  var password = req.swagger.params['password'].value;
  User.loginUser(email,password)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.logoutUser = function logoutUser (req, res, next) {
  User.logoutUser()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateUser = function updateUser (req, res, next) {
  var username = req.swagger.params['username'].value;
  var body = req.swagger.params['body'].value;
  User.updateUser(username,body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
